#ifndef STRINGS_H
#define STRINGS_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include <string.h>
#include <stdlib.h>

//
// String
//
class String {
private:
  int size;
  char* text;
public:
  String(const char* t = NULL);
  String(const char* t1, const char* t2);
  String(int val);
  ~String();
  int getSize() {return size;}
  int getLength() {return strlen(text);}
  void setLength(int len)
    {if(strlen(text) > (unsigned int)len) text[len] = '\0';}
  char* getText() {return text;}
  void setText(const char* t);
  void concat(const char* t);
  void insert(char c, int pos);
  void del(int pos);
  int getInt() {return atoi(text);}
  void setInt(int value);
  static bool equals(char* t1, char* t2) {return strcmp(t1,t2) == 0;}
  bool equals(String* s) {return equals(getText(),s->getText());}
  bool equals(char* t) {return equals(getText(),t);}
};

#endif // STRINGS_H
