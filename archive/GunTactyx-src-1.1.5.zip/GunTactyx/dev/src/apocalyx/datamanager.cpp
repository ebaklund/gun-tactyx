/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "datamanager.h"

#include <mem.h>

//
// DMReference
//
DMReference::DMReference(): referencesCount(0) {
}

#ifdef CHECK_MEMORY_LEAKS
ofstream DMReference::CHECK_LEAKS("CHECK_LEAKS.txt");
#endif

//
// DMCache
//

DMCache::DMCache(int siz): data(new char[siz]), size(siz) {
}

void DMCache::destroyObject() {
  if(data) delete data;
  delete this;
}

void DMCache::resize(int siz, bool copy) {
  if(copy && data) {
    char* oldData = data;
    int oldSize = size;
    data = new char[size = siz];
    memcpy(data,oldData,oldSize);
    delete oldData;
  } else {
    if(data) delete data;
    data = new char[size = siz];
  }
}

