#ifndef EXCEPTION_H
#define EXCEPTION_H

/*
  Copyright (C) 2001-2005 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "opengl.h"

#if defined(USE_GLFW) || defined(USE_OGLES)
#include <stdio.h>
#endif // USE_GLFW || USE_OGLES

//
// Exception
//

class ExceptionThrown {
protected:
  static ExceptionThrown instance;
  static char* message;
public:
  static char* getMessage() {return message;}
  static void setMessage(char* msg) {message = msg;}
#if !defined(USE_GLFW) && !defined(USE_OGLES)
  static void showWarning(const char* text, const char* title)
    {MessageBox(GetActiveWindow(),text,title,MB_ICONWARNING|MB_OK|MB_TASKMODAL);}
  static void showError(const char* text, const char* title)
    {MessageBox(GetActiveWindow(),text,title,MB_ICONERROR|MB_OK|MB_TASKMODAL);}
#else // USE_GLFW || USE_OGLES
  static void showWarning(const char* text, const char* title)
    {printf("WARNING: %s - %s",title,text);}
  static void showError(const char* text, const char* title)
    {printf("ERROR: %s - %s",title,text);}
#endif // USE_GLFW || USE_OGLES
};

class Exception: public ExceptionThrown {
public:
  static void throws(char* msg) throw(ExceptionThrown);
};

#endif // EXCEPTION_H
