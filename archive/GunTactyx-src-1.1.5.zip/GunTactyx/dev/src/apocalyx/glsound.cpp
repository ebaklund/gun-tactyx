/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_SOUND

#include "glsound.h"

#include "glwin.h"

#include "math3d.inc"

//
// GLSoundSource
//

GLSoundSource::GLSoundSource(FM3DSample* s, GLObject* o, bool playing):
  sound(s->create3DSound(playing)), object(o)
{}

GLSoundSource::~GLSoundSource() {
  delete sound;
}

void GLSoundSource::render(GLCamera& camera) {
  const M3Vector& pos = object->getPosition();
  M3Vector velocity(pos.getX(),pos.getY(),pos.getZ());
  velocity.subtract(lastRenderingPosition).scale(GLWin::getInvTimeStep());
  lastRenderingPosition.set(pos.getX(),pos.getY(),pos.getZ());
  sound->setAttributes(lastRenderingPosition.getArray(),velocity.getArray());
}

#endif // USE_SOUND
