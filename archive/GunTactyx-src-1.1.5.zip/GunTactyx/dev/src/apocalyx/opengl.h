#ifndef OPENGL_H
#define OPENGL_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef __linux__
#define USE_GLFW
#else // __linux__
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif // __linux__

#ifdef USE_OGLES

#include "gles/glutes.h"

#else // !USE_OGLES

#ifndef USE_GLFW
#include "GL/gl.h"
#include "GL/glu.h"
#else // USE_GLFW
#include "glfw/glfw.h"
#endif // USE_GLFW
#include "GLext/glext.h"

#endif // !USE_OGLES

#endif // OPENGL_H
