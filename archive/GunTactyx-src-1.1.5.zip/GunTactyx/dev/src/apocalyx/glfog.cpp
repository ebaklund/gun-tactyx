/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glfog.h"

#include "opengl.h"
#include <math.h>

//
// GLFog
//

GLFog::GLFog():
	fogEnabled(false), fogLinear(true), fogColor(0,0,0,1),
  fogDist(0), fogMaxDist(1)
{}

void GLFog::renderFog() {
  if(fogEnabled) {
	  glEnable(GL_FOG);
	  glFogfv(GL_FOG_COLOR,fogColor.getFloatArray());
    if(fogLinear) {
	  	glFogf(GL_FOG_MODE,GL_LINEAR);
  		glFogf(GL_FOG_START,fogDist);
  		glFogf(GL_FOG_END,fogMaxDist);
    } else {
	  	glFogf(GL_FOG_MODE,GL_EXP2);
  		glFogf(GL_FOG_DENSITY,sqrt(4.60517f/(fogDist*fogDist)));
    }
  } else {
		glDisable(GL_FOG);
  }
}

