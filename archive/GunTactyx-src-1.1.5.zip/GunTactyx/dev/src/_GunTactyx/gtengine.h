#ifndef GTENGINE_H
#define GTENGINE_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "apocalyx/slinterpreter.h"

//
// GTEngineScript
//
#define ENGINE_CPU_FREQUENCY_INIT 10000

class GTEngineScript: public SLInterpreter {
protected:
  int timerCountdown;
public:
  GTEngineScript();
  bool load(char* scriptName);
  static void decreaseTimer(int ticks) {amx_timer -= ticks;}
  int execute(float timeStep) {
    if(!isRunning())
      return AMX_ERR_NONE;
    timerCountdown += int(timeStep*getCPUFrequency()+0.5f);
    int ret = execMain(timerCountdown);
    timerCountdown = amx_timer;
    return ret;
  }
};

#endif // GTENGINE_H
