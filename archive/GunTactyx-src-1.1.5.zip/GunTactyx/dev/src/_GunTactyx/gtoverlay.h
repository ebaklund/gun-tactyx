#ifndef GTOVERLAY_H
#define GTOVERLAY_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gtsim.h"

#include "apocalyx/gloverlay.h"

//
// GTOverlayArenaData
//
class GTOverlayArenaData: public GLOverlayObject {
private:
  GTArena* arena;
  GLFont* font;
public:
  GTOverlayArenaData(GLFont* f, GTArena* a = NULL);
  ~GTOverlayArenaData();
  void setArena(GTArena* a) {arena = a;}
  virtual void render(GLCamera& camera);
};

//
// GTOverlayArenaMap
//
class GTOverlayArenaMap: public GLOverlayObject {
private:
  GTArena* arena;
  GLTexture* texture;
public:
  GTOverlayArenaMap(GLTexture* t, GTArena* a = NULL);
  ~GTOverlayArenaMap();
  void setArena(GTArena* a) {arena = a;}
  virtual void render(GLCamera& camera);
};

#endif // GTOVERLAY_H
